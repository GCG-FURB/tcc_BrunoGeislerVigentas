using System.Reflection;

// DON'T EDIT
// Will be replaced by Tools/Build/build.py
[assembly: AssemblyVersion("1.3.2.0")]
[assembly: AssemblyFileVersion("1.3.2.0")]

